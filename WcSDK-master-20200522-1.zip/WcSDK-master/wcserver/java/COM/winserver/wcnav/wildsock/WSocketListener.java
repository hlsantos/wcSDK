package COM.winserver.wcnav.wildsock;

public interface WSocketListener {
  public void socketNotify(WSocket socket);
}
