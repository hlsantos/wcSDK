//***********************************************************************
// (c) Copyright 1998-2008 Santronics Software, Inc. All Rights Reserved.
//***********************************************************************
//
// File Name : common.h
// Subsystem :
// Date      :
// Version   :
// Author    :
//
// Revision History:
// Build    Date      Author  Comments
// -----    --------  ------  -------------------------------------------
//***********************************************************************
#pragma once

#include <wccompiler.h>

#include <afx.h>
#include <afxwin.h>
#include <afxtempl.h>
#include <winsock.h>
#include <process.h>

#include "resource.h"

#include "wcserver.h"
#include "wclinker.h"
#include "globals.h"
#include "trvsrvr.h"
