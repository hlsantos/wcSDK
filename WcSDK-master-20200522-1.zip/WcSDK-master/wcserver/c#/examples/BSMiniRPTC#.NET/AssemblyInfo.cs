using System;
using System.Collections;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.



[assembly: AssemblyTitle("bsMini Reports C# .NET")]
[assembly: AssemblyDescription("Winserver SDK Example for C# .NET")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("bsMini Reports C# .NET")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:

//	Major version
//	Minor Version
//	Build Number
//	Revision

// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:

[assembly: AssemblyVersion("8.0.454.8")]
[assembly: ComVisibleAttribute(false)]
[assembly: AssemblyFileVersion("8.0.454.8")]

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
