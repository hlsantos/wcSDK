//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wctrivia.rc
//
#define IDB_BITMAP1                     101
#define IDD_MAINFRAME                   102
#define IDC_SERVERNAME                  1001
#define IDC_IPADDRESS                   1002
#define IDC_CONNECTIONS                 1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
