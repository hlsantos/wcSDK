#pragma once

#ifdef _WIN64
#   pragma comment(lib, "wcsgate64.lib")
#else
#   pragma comment(lib, "wcsgate.lib")
#endif
