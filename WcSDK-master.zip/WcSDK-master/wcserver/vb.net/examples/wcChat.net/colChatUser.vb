Public Class colChatUser

    Inherits System.Collections.Generic.List(Of clsChatUser)
    Implements IEnumerable

End Class
