<?php

  print "hello world!\n";

  fgets(STDIN);

?>
