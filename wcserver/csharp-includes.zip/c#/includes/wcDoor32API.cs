//***********************************************************************
// (c) Copyright 1998-2020 Santronics Software, Inc. All Rights Reserved.
//***********************************************************************
//
// File Name : wcdoor32.cs
// Subsystem : Wildcat! Door32
// Date      : 04/16/2020
// Version   : 8.0.454.10
// Author    : HLS/SSI
//
// Revision History:
// Build    Date      Author  Comments
// -----    --------  ------  -------------------------------------------
// 452.5    03/07/08  HLS     - Added WCDOOR_EVENT_XXXXXX
//                            - Added DoorEvent()
//
// 452.6    10/01/08  HLS     - For consistency and to help reduce
//                              long time conflict with door32.sys,
//                              door32.h was renamed to wcdoor32.h
//
// 454.10   04/16/20  HLS     - C# version of wcDoor32 header
//***********************************************************************

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace wcSDK
{
	public static class wcDoor32API
	{

	#region Credits ...

		// ------------------------------------------------------------------------
		// (c) Copyright 1998-2020 by Santronics Software Inc. All Rights Reserved.
		// Wildcat! Door 32bit API v8.0.454.10
        //
        // CUSTOM/MANUALLY UPDATED
		// ------------------------------------------------------------------------

	#endregion

	#region Public Wildcat! Door32 API Constants ...

        public const int WCDOOR_EVENT_BASE        = 0;
        public const int WCDOOR_EVENT_FAILED      = WCDOOR_EVENT_BASE + 0;
        public const int WCDOOR_EVENT_TIMEOUT     = WCDOOR_EVENT_BASE + 1;
        public const int WCDOOR_EVENT_KEYBOARD    = WCDOOR_EVENT_BASE + 2;
        public const int WCDOOR_EVENT_OFFLINE     = WCDOOR_EVENT_BASE + 3;

	#endregion

	#region Public Wildcat! Door32  API Structures ...
	#endregion

	#region Public Wildcat! Door32 API DLL Imports ...

	////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorInitialize
		////! Initialize a wcDoor32 application
		////! returns TRUE if successful, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static bool DoorInitialize();

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorShutdown
		////! Shutdown a wcDoor32 application.
		////! returns TRUE if successful, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static bool DoorShutdown();

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorHangUp
		////! Disconnect (hangup) communications with user
		////! returns TRUE if successful, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static bool DoorHangUp();

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorCharReady
		////! Check if a character is available to be read or peeked.
		////! returns TRUE if successful, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static int DoorCharReady();


		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorRead
		////! Read a character from input buffer
		////! returns number of bytes read otherwise 0
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static int DoorRead(ref byte[] data, int size);

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorPeek
		////! Read/Peek a character without removing from input buffer.
		////! returns number of bytes peeked otherwise 0
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static int DoorPeek(ref byte[] data, int size);

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorWrite
		////! Write characters to output buffer
		////! returns TRUE if data is written, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static bool DoorWrite(ref byte[] data, int size);

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorGetAvailableEventHandle
		////! get the event handle to process
		////! returns HANDLE if successful, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static int DoorGetAvailableEventHandle();

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorGetOfflineEventHandle
		////! get the offline handle to process
		////! returns HANDLE if successful, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static int DoorGetOfflineEventHandle();

		////!----------------------------------------------------------------
		////! Group: wcDoor32 API
		////! DoorEvent
		////! Get the event if any with a timeput
		////! returns event handle if successful, otherwise see extended error
		////!----------------------------------------------------------------
		[DllImport("wcdoor32.dll", SetLastError=true)]
		public extern static int DoorEvent(int timeout);

	#endregion

	}

} //end of root namespace
