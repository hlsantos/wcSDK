//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UserList.rc
//
#define IDTEST                          3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USERLIST_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_USERDLG                     129
#define IDD_USERDISPLAY                 130
#define IDDISPLAY                       1000
#define IDC_USERLIST                    1001
#define IDC_STATICNAME                  1004
#define IDC_NAMETXT                     1005
#define IDC_STATICFROM                  1014
#define IDC_FROMTXT                     1015
#define IDC_STATICSECURITY              1016
#define IDC_SECURITYTXT                 1017
#define IDC_STATICREALNAME              1018
#define IDC_REALNAMETXT                 1019
#define IDC_STATICPHONE                 1020
#define IDC_PHONETXT                    1021
#define IDC_STATICCOMPANY               1022
#define IDC_COMPANYTXT                  1023
#define IDC_STATICADDRESS1              1030
#define IDC_ADDRESS1TXT                 1031
#define IDC_STATICADDRESS2              1032
#define IDC_ADDRESS2TXT                 1033
#define IDC_STATICCITY                  1034
#define IDC_CITYTXT                     1035
#define IDC_STATICSTATE                 1036
#define IDC_STATETXT                    1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
