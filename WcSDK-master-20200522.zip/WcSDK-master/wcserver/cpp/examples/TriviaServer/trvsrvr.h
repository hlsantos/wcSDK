//***********************************************************************
// (c) Copyright 1998-2008 Santronics Software, Inc. All Rights Reserved.
//***********************************************************************
//
// File Name : trvsrvr.h
// Subsystem :
// Date      :
// Version   :
// Author    :
//
// Revision History:
// Build    Date      Author  Comments
// -----    --------  ------  -------------------------------------------
//***********************************************************************

#ifndef __trvsrvr_h
#define __trvsrvr_h

const char  WCTRIVIA_VERSION_STR[] = "3.00";
const DWORD WCTRIVIA_VERSION       = 0x0300;

void ListenThread(void *p);

#endif
