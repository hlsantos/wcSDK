
#pragma once

#pragma message("note: The WCSDK door32.h header was renamed to wcdoor32.h")

#include "wcdoor32.h"
