//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ReadMsg.rc
//
#define IDTEST                          3
#define ID_TEST                          3
#define ID_SECLIST                      5
#define ID_NEXT                         3
#define ID_PREVIOUS                     4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_READMSG_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_CONFDLG                     129
#define IDD_MESSAGEDLG                  130
#define IDC_CONFLIST                    1000
#define IDC_STATICTO                    1002
#define IDC_STATICFROM                  1003
#define IDC_STATICSUBJECT               1004
#define IDC_TOTXT                       1005
#define IDC_FROMTXT                     1006
#define IDC_SUBJECTTXT                  1007
#define IDC_STATICCONF                  1008
#define IDC_CONFTXT                     1009
#define IDC_STATICMSGNUM                1010
#define IDC_MSGNUMTXT                   1011
#define IDC_CHECKPRIVATE                1013
#define IDC_CHECKRETURN                 1014
#define IDC_MSGTXT                      1016
#define IDC_SELECTALL                   1017
#define IDC_DESELECTALL                 1018
#define IDC_TOGGLE                      1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
