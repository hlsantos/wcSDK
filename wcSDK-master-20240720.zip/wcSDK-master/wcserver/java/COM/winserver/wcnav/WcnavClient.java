package COM.winserver.wcnav;

public interface WcnavClient extends Runnable {
  public void stop();
}
